ALTER TABLE "orders" ADD COLUMN "address_full_name" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "address_street" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "address_house_number" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "address_postal_code" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "address_city" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "address_additional_info" text;